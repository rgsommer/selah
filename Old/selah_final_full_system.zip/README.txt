
Selah Final System - All Features Included

Features:
- Image rotation (landscape/portrait)
- Manual & touch navigation
- Email photo intake with caption and future date scheduling
- On-screen toast notifications
- Verse of the Day (YouVersion/Sheet/local)
- Google Calendar integration
- Motion detection & night light
- Facial recognition (optional filtering)
- Google Drive cloud backup
- Config GUI, sender manager, leaderboard
- Midnight scheduler for special-day media
- Full install script

Run with:
  chmod +x install_selah.sh
  ./install_selah.sh
  python3 media_display.py
