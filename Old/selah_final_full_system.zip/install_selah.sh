#!/bin/bash
sudo apt update && sudo apt install -y python3-pygame python3-pip libtiff-dev libjpeg-dev
pip3 install pygame Pillow requests
