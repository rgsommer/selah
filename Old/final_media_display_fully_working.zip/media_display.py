
import os
import time
import json
import pygame
import datetime
from pathlib import Path
from random import shuffle
from email_handler import check_for_new_emails
from motion_detector import detect_motion
from calendar_display import show_calendar_if_scheduled
from verse_handler import show_verse_if_scheduled
from toast import show_toast_if_needed
from face_recognition_handler import prioritize_images

def load_config(path="display_config.json"):
    with open(path, "r") as f:
        return json.load(f)

def init_display():
    pygame.init()
    screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
    pygame.mouse.set_visible(False)
    return screen

def show_image(screen, image_path):
    try:
        image = pygame.image.load(image_path)
        img_w, img_h = image.get_size()
        scr_w, scr_h = screen.get_size()
        scale = min(scr_w / img_w, scr_h / img_h)
        image = pygame.transform.scale(image, (int(img_w * scale), int(img_h * scale)))
        x = (scr_w - image.get_width()) // 2
        y = (scr_h - image.get_height()) // 2
        screen.fill((0, 0, 0))
        screen.blit(image, (x, y))
        pygame.display.flip()
        print(f"Displayed: {image_path}")
    except Exception as e:
        print(f"Error displaying {image_path}: {e}")

def get_images(folder):
    return sorted([str(p) for p in Path(folder).glob("*") if p.suffix.lower() in [".jpg", ".jpeg", ".png"]])

def main():
    config = load_config()
    screen = init_display()
    rotate_interval = config.get("rotate_interval", 10)
    manual_pause = config.get("manual_navigation_pause", 60)

    portrait_files = get_images(config["portrait_dir"])
    landscape_files = get_images(config["landscape_dir"])
    if config.get("enable_face_recognition"):
        portrait_files = prioritize_images(portrait_files, config)
        landscape_files = prioritize_images(landscape_files, config)

    shuffle(portrait_files)
    shuffle(landscape_files)

    index_portrait = 0
    index_landscape = 0
    last_switch_time = time.time()
    paused_until = 0

    while True:
        now = datetime.datetime.now()
        time_str = now.strftime("%H:%M")

        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    exit()
                elif event.key == pygame.K_LEFT and landscape_files:
                    index_landscape = (index_landscape - 1) % len(landscape_files)
                    paused_until = time.time() + manual_pause
                elif event.key == pygame.K_RIGHT and landscape_files:
                    index_landscape = (index_landscape + 1) % len(landscape_files)
                    paused_until = time.time() + manual_pause
                elif event.key == pygame.K_UP and portrait_files:
                    index_portrait = (index_portrait - 1) % len(portrait_files)
                    paused_until = time.time() + manual_pause
                elif event.key == pygame.K_DOWN and portrait_files:
                    index_portrait = (index_portrait + 1) % len(portrait_files)
                    paused_until = time.time() + manual_pause

        on_time = datetime.datetime.strptime(config["on_time"], "%H:%M").time()
        off_time = datetime.datetime.strptime(config["off_time"], "%H:%M").time()

        if now.time() < on_time or now.time() > off_time:
            from quote_loader import show_clock_with_quote
            show_clock_with_quote(screen, config)
            time.sleep(10)
            continue

        check_for_new_emails(config, screen)
        detect_motion(config, screen)
        show_toast_if_needed(screen, config)

        if config.get("verse_display_enabled"):
            show_verse_if_scheduled(screen, config)

        if config.get("calendar_display_enabled"):
            show_calendar_if_scheduled(screen, config)

        if time.time() < paused_until:
            time.sleep(1)
            continue

        if landscape_files:
            show_image(screen, landscape_files[index_landscape])
            index_landscape = (index_landscape + 1) % len(landscape_files)
        elif portrait_files:
            show_image(screen, portrait_files[index_portrait])
            index_portrait = (index_portrait + 1) % len(portrait_files)

        time.sleep(rotate_interval)

if __name__ == "__main__":
    main()
